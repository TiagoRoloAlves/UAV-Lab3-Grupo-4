import numpy as np
import matplotlib.pyplot as plt

# --- Parameters ---
m = 0.035                # mass (kg)
g = 9.81                 # gravity (m/s^2)
D = np.diag([9.1785, 9.1785, 10.311]) * 1e-7  # drag matrix

# PD gains (further increased Kp_z for exact ramp to 1 by t=3s)
Kp = np.diag([50.0, 50.0, 400.0])    # higher proportional gain on z
Kd = np.diag([10.0, 10.0, 100.0])    # derivative gains

dt = 0.01                # time step
T_final = 5.0
N = int(T_final/dt)

# Reference trajectory (ramp to [1,1,1] in 3s)
def ref_traj(t):
    if t < 3.0:
        p_ref = np.array([t/3, t/3, t/3])
        v_ref = np.array([1/3, 1/3, 1/3])
        a_ref = np.zeros(3)
    else:
        p_ref = np.ones(3)
        v_ref = np.zeros(3)
        a_ref = np.zeros(3)
    return p_ref, v_ref, a_ref

# Full rotation matrix (zero yaw)
def R_full(phi, theta):
    R_y = np.array([[ np.cos(theta), 0, np.sin(theta)],
                    [             0, 1,             0],
                    [-np.sin(theta), 0, np.cos(theta)]])
    R_x = np.array([[1,             0,              0],
                    [0, np.cos(phi), -np.sin(phi)],
                    [0, np.sin(phi),  np.cos(phi)]])
    return R_y @ R_x

# Map total accel to roll/pitch
def acc_to_angles(a):
    a_corr = a - np.array([0,0,-g])
    phi   = np.arctan2(a_corr[1],   a_corr[2])
    theta = np.arctan2(-a_corr[0],  a_corr[2])
    return phi, theta

# Logs
p = np.zeros((3,N))
v = np.zeros((3,N))
phi_log = np.zeros(N)
theta_log = np.zeros(N)

# Initial state: all zeros
p[:,0] = np.zeros(3)
v[:,0] = np.zeros(3)

# Simulation
for k in range(N-1):
    t = k*dt
    p_ref, v_ref, a_ref = ref_traj(t)
    e_p = p[:,k] - p_ref
    e_v = v[:,k] - v_ref

    # Feed-forward: cancel drag & track ref accel
    u_ff = a_ref + (1/m)*(D @ v_ref)

    # PD control
    u_ctrl = -Kp @ e_p - Kd @ e_v

    # Total accel command (re-add gravity)
    a_total = u_ff + u_ctrl + np.array([0,0,-g])

    # Get attitude
    phi, theta = acc_to_angles(a_total)
    phi_log[k] = phi
    theta_log[k] = theta

    # Propagate
    R = R_full(phi, theta)
    p_dot = R @ v[:,k]
    v_dot = -(1/m)*(D @ v[:,k]) + a_total

    p[:,k+1] = p[:,k] + p_dot * dt
    v[:,k+1] = v[:,k] + v_dot * dt

# Plotting
time = np.linspace(0, T_final, N)
fig, (ax1,ax2) = plt.subplots(2,1, figsize=(8,6), sharex=True)

for i,label in enumerate(['x','y','z']):
    ax1.plot(time, p[i], label=label)
ax1.set_ylabel('Position (m)')
ax1.legend(); ax1.grid(True)

for i,label in enumerate(['vx','vy','vz']):
    ax2.plot(time, v[i], label=label)
ax2.set_xlabel('Time (s)')
ax2.set_ylabel('Velocity (m/s)')
ax2.legend(); ax2.grid(True)

plt.tight_layout()
plt.show()
# Compute position RMSE
p_target = np.ones((3, p.shape[1]))  # desired final position is [1,1,1] throughout
p_errors = np.linalg.norm(p - p_target, axis=0)
pRMSE = np.sqrt(np.mean(p_errors**2))

# Compute velocity RMSE (target is zero velocity)
v_errors = np.linalg.norm(v, axis=0)
vRMSE = np.sqrt(np.mean(v_errors**2))

# Print results
print(f"Simulated pRMSE = {pRMSE:.3f} m")
print(f"Simulated vRMSE = {vRMSE:.3f} m/s")
